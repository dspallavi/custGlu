import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import * as skills from "../../skills.json";
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { SkillInfo } from 'src/app/models/company';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.scss']
})
export class SkillsComponent implements OnInit {
  displayedColumns = ['skillName', 'skillRating', 'actions'];
  dataSource: any;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @Input() addedSkills: any = [];
  skillsInfoFrom: FormGroup = new FormGroup({
    skillName: new FormControl('', [Validators.required]),
    skillRating: new FormControl('', [Validators.required])
  });
  skillList: Array<any> = skills.default;
  @Output() updateSkills: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnChanges(changes: SimpleChanges) {
    if (changes["addedSkills"].currentValue !== changes["addedSkills"].previousValue) {
      this.addedSkills = changes["addedSkills"].currentValue || [];
      this.inItTable();
    }
  }

  ngOnInit(): void {
    this.inItTable();
  }

  inItTable() {
    this.dataSource = new MatTableDataSource(this.addedSkills);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.updateSkills.emit(this.addedSkills);
  }

  deleteSkill(skill: SkillInfo) {
    this.addedSkills = this.addedSkills.filter((s: SkillInfo) => {
      return (s.skillName !== skill.skillName);
    });
    this.inItTable();
  }

  addSkill() {
    if (this.skillsInfoFrom.valid) {
      this.addedSkills.push(this.skillsInfoFrom.value);
      this.inItTable();
      this.skillsInfoFrom.reset();
    }
  }

  filterSkills(e: any) {
    this.skillList = skills.default.filter((skill: any) => skill.name.toLowerCase().includes(e.target.value.toLowerCase()));
  }
}
