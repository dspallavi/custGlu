import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewCompanyRoutingModule } from './new-company-routing.module';
import { NewCompanyComponent } from './new-company.component';
import { CustomSharedModule } from '../shared/custom-shared.module';
import { DataService } from '../service/data.service';
import { SkillsComponent } from './skills/skills.component';


@NgModule({
  declarations: [NewCompanyComponent, SkillsComponent],
  imports: [
    CommonModule,
    NewCompanyRoutingModule,
    CustomSharedModule
  ],
  providers: [DataService]
})
export class NewCompanyModule { }
