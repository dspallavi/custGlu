import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CompanyProfile, SkillInfo } from '../models/company';
import { DataService } from '../service/data.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { SkillsComponent } from './skills/skills.component';

@Component({
  selector: 'app-new-company',
  templateUrl: './new-company.component.html',
  styleUrls: ['./new-company.component.scss']
})
export class NewCompanyComponent implements OnInit {
  id: string = '';
  loading = false;
  maxDate = new Date().setDate(new Date().getDate() - 1);
  panelOpenState: any;
  companyProfile: FormGroup = new FormGroup({
    companyName: new FormControl('', [Validators.required]),
    companyAddress: new FormControl('', []),
    email: new FormControl('', [Validators.required]),
    phoneNumber: new FormControl('', [Validators.required]),
  });
  employeeInfo: FormGroup = new FormGroup({
    employeeName: new FormControl('', [Validators.required]),
    designation: new FormControl('', [Validators.required]),
    joinDate: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
    phoneNumber: new FormControl('', [Validators.required]),
  });

  educationInfo: FormGroup = new FormGroup({
    instituteName: new FormControl('', [Validators.required]),
    courseName: new FormControl('', [Validators.required]),
    completedYear: new FormControl('', [Validators.required])
  });
  addedSkills: Array<SkillInfo> = [];
  selectedFile: any;
  selectedFileName: string = '';
  preview: any;

  constructor(private dataService: DataService, private _snackBar: MatSnackBar, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params: any) => {
      if (params.companyId) {
        this.id = params.companyId;
        this.loading = true;
        this.dataService.getCompanyById(params.companyId).then((company: any) => {
          this.updateFormFields(company);
        });
      }
    })
  }

  onSubmitForm() {
    if (!this.educationInfo.valid) {
      return;
    }
    this.loading = true;
    if (this.id) {
      this.dataService.updateCompany(new CompanyProfile(
        this.companyProfile.value,
        this.id,
        this.employeeInfo.value,
        this.addedSkills,
        this.educationInfo.value, this.selectedFileName, this.preview)).then((res) => {
          this._snackBar.open('Company updated successfully.', 'Dismiss');
          this.loading = false;
        });
    } else {
      this.dataService.saveCompany(new CompanyProfile(
        this.companyProfile.value,
        this.id,
        this.employeeInfo.value,
        this.addedSkills,
        this.educationInfo.value, this.selectedFileName, this.preview)).then((res) => {
          this._snackBar.open('Company saved successfully.', 'Dismiss');
          this.loading = false;
        });
    }
  }

  updateFormFields(companyDetails: any) {
    const empDetails = companyDetails.employeeInfo[0];
    const eductionInfo = companyDetails.employeeInfo[0].eductionInfo[0];
    this.selectedFileName = companyDetails.selectedFileName;
    this.preview = companyDetails.preview;
    this.companyProfile.patchValue({
      companyName: companyDetails.companyName,
      companyAddress: companyDetails.companyAddress,
      email: companyDetails.email,
      phoneNumber: companyDetails.phoneNumber
    });
    this.employeeInfo.patchValue({
      employeeName: empDetails.employeeName,
      email: empDetails.email,
      phoneNumber: empDetails.phoneNumber,
      joinDate: empDetails.joinDate,
      designation: empDetails.designation,
    })
    this.addedSkills = companyDetails.employeeInfo[0].skillsInfo;
    this.educationInfo.patchValue({
      completedYear: eductionInfo.completedYear,
      courseName: eductionInfo.courseName,
      instituteName: eductionInfo.instituteName,
    });
    this.loading = false;
  }

  updateSkills(list: any) {
    this.addedSkills = list
  }

  selectFiles(event: any): void {
    this.selectedFile = event.target.files;
    if (this.selectedFile && this.selectedFile[0]) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.preview = e.target.result;
      };
      reader.readAsDataURL(this.selectedFile[0]);
      this.selectedFileName = this.selectedFile[0].name
    }
  }

  removeProfile() {
    this.selectedFileName = "";
    this.preview = "";
  }
}
