import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CompanyProfile } from '../models/company';

@Injectable()
export class DataService {
  dataChange: BehaviorSubject<CompanyProfile[]> = new BehaviorSubject<CompanyProfile[]>([]);

  constructor() { }

  get data(): CompanyProfile[] {
    return this.dataChange.value;
  }

  getAllCompanies(): void {
    const companyProfile: CompanyProfile[] = this.getDataFRomLocalStorage();
    this.notifyDataChange(companyProfile);
  }

  notifyDataChange(companyProfile: CompanyProfile[]) {
    this.dataChange.next(companyProfile);
  }

  saveCompany(companyData: CompanyProfile) {
    const promise = new Promise((resolve, reject) => {
      let profile: CompanyProfile[] = this.getDataFRomLocalStorage();
      profile.push(companyData);
      this.notifyDataChange(profile);
      localStorage.setItem('companyProfile', JSON.stringify(profile));
      setTimeout(() => {
        resolve(profile);
      }, 500)// to show the spinner 
    });
    return promise;
  }

  updateCompany(companyData: CompanyProfile) {
    const promise = new Promise((resolve, reject) => {
      let profile: CompanyProfile[] = this.getDataFRomLocalStorage();
      profile = profile.map((company: CompanyProfile) => {
        if (companyData.id === company.id) {
          return companyData;
        }
        return company;
      });
      this.notifyDataChange(profile);
      setTimeout(() => {
        resolve(profile);
      }, 500) // to show the spinner 
      localStorage.setItem('companyProfile', JSON.stringify(profile));
    });
    return promise;
  }

  deleteCompany(id: string) {
    const promise = new Promise((resolve, reject) => {
      let profile: CompanyProfile[] = this.getDataFRomLocalStorage();
      profile = profile.filter((company: CompanyProfile) => company.id !== id);
      this.notifyDataChange(profile);
      localStorage.setItem('companyProfile', JSON.stringify(profile));
      setTimeout(() => {
        resolve(profile);
      }, 500) // to show the spinner 
    });
    return promise;
  }

  getDataFRomLocalStorage(): CompanyProfile[] {
    const data: string = localStorage.getItem('companyProfile') || '';
    return data ? JSON.parse(data) : [];
  }

  getCompanyById(id: string) {
    const promise = new Promise((resolve, reject) => {
      let profile: CompanyProfile[] = this.getDataFRomLocalStorage();
      const company = profile.filter((company: CompanyProfile) => company.id === id)[0];
      setTimeout(() => {
        resolve(company);
      }, 500) // to show the spinner 
    });
    return promise;
  }
}