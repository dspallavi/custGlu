export class CompanyProfile {
  id: string;
  companyName: string;
  companyAddress: string;
  email: string;
  phoneNumber: any;
  employeeInfo: Array<EmployeeInfo>;
  selectedFileName: string;
  preview: string;

  constructor(formData: any, id: string, empData: any, skillData: any, educationInfo: any, fileName: string, preview: string) {
    this.id = id ? id : Math.random().toString(16).slice(2);
    this.companyName = formData.companyName;
    this.companyAddress = formData.companyAddress;
    this.email = formData.email;
    this.phoneNumber = formData.phoneNumber;
    this.employeeInfo = [new EmployeeInfo(empData, skillData, educationInfo)];
    this.selectedFileName = fileName;
    this.preview = preview;
  }
}

export class EmployeeInfo {
  employeeName: string;
  designation: string;
  joinDate: string;
  email: string;
  phoneNumber: any;
  skillsInfo: Array<SkillInfo>;
  eductionInfo: Array<EducationInfo>;

  constructor(formData: any, skillData: any, educationInfo: any) {
    this.employeeName = formData.employeeName;
    this.designation = formData.designation;
    this.joinDate = formData.joinDate;
    this.email = formData.email;
    this.phoneNumber = formData.phoneNumber;
    this.skillsInfo = skillData
    this.eductionInfo = [educationInfo]
  }
}

export interface SkillInfo {
  skillName: string;
  skillRating: string;
}

export interface EducationInfo {
  instituteName: string;
  courseName: string;
  completedYear: string;
}